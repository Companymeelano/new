# M•REPORT Executive Edition — Milano Studio Design

سامانه گزارش‌گیری Read Only برای سرویس گزارش آتیران، مناسب cPanel، موبایل Android/iPhone، تبلت و دسکتاپ.

## قابلیت‌ها
- چهار تم: Obsidian Neon، Royal Gold، Pearl Azure، Ivory Sage
- داشبورد مدیریتی با نمودارهای 3D/Glass و کارت‌های KPI
- مشتریان، کالاها، موجودی، فاکتورها، مطالبات، چک‌ها، پیام‌ها و اطلاعات شرکت
- پرونده مشتری با تماس مستقیم، پیام مستقیم، چاپ، Excel، اشتراک‌گذاری و یادآور
- چاپ مرورگر/PDF از طریق Print to PDF
- خروجی CSV، Excel-compatible و Word-compatible بدون وابستگی به کتابخانه خارجی
- Web Share API برای اشتراک فایل روی موبایل؛ در صورت پشتیبانی، پنل اشتراک سیستم باز می‌شود و کاربر می‌تواند WhatsApp/Instagram/Bale/Rubika و سایر برنامه‌های نصب‌شده را انتخاب کند.
- یادآور با localStorage و Notification API؛ برای نوتیفیکیشن مطمئن در حالت بسته بودن مرورگر، PWA + Service Worker/Push در مرحله بعد توصیه می‌شود.
- Responsive برای Android/iPhone/iPad/Tablet/Desktop

## نصب cPanel
1. PHP 8.2/8.3 یا بالاتر فعال باشد و cURL، JSON و Sessions در دسترس باشند.
2. محتویات `public/` را داخل public_html/mreport قرار دهید.
3. پوشه `config` را ترجیحاً خارج از public_html قرار دهید یا با `.htaccess` از دسترسی مستقیم محافظت کنید.
4. `config/config.example.php` را به `config.php` تبدیل کنید و فقط آدرس سرویس آتیران را تنظیم کنید.
5. رمز SQL Server را داخل HTML یا APK قرار ندهید؛ Backend باید واسط سرویس باشد.
6. در `public/api/bootstrap.php` مسیر config بررسی شود.

## نکته درباره PDF/Word/Excel
PDF با print engine مرورگر ساخته می‌شود تا بدون کتابخانه خارجی روی cPanel کار کند. Excel و Word به‌صورت فایل سازگار با Office تولید می‌شوند. برای PDF/Excel کاملاً استاندارد و حرفه‌ای در مرحله سرور می‌توان از کتابخانه‌های PHP مثل Dompdf/PhpSpreadsheet استفاده کرد.

## داده و دقت
گزارش‌ها فقط از endpointهای موجود در پروژه آتیران استفاده می‌کنند. محاسبات جدید فقط زمانی باید اضافه شوند که فیلد/endpoint واقعی آن در API مشخص باشد؛ عدد یا ستون ساختگی تولید نمی‌شود.
