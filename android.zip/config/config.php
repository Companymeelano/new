<?php
// Copy this file to config.php and fill the Atiran credentials.
// Keep this file outside public_html when possible.
return [
    'atiran_service_url' => 'http://37.143.147.19/LocalServices.svc',
    'atiran_username' => 'AdminAn',
    'atiran_password' => 'St@R2022$',
    'cpuid' => 'MREPORT-CPL-01',
    'session_name' => 'mreport_session',
    'allowed_origins' => ['*'],
];
